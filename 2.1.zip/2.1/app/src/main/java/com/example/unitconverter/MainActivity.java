package com.example.unitconverter;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        Spinner spinner = findViewById(R.id.menu);
        EditText input = findViewById(R.id.measurementInput);
        TextView textView = findViewById(R.id.textView);
        TextView textView2 = findViewById(R.id.textView2);
        TextView textView3 = findViewById(R.id.textView3);
        ImageButton imageButton = findViewById(R.id.imageButton);
        ImageButton imageButton2 = findViewById(R.id.imageButton2);
        ImageButton imageButton3 = findViewById(R.id.imageButton3);

        imageButton.setOnClickListener((View v) -> {
            if (spinner.getSelectedItem().toString().equals("Meter") )
            {
                float calcValue = Float.parseFloat(input.getText().toString());
                textView.setText( (String.format("%.2f", (100*calcValue)))+ " Centimetre");
                textView2.setText( (String.format("%.2f", ((3.28084)*calcValue)))+ " Foot");
                textView3.setText( (String.format("%.2f", ((39.3701)*calcValue)))+ " Inch");
            }
            else
            {
                textView.setText("");
                textView2.setText("");
                textView3.setText("");
                Toast.makeText( MainActivity.this ,  "Wrong Conversion Button !",Toast.LENGTH_LONG).show();
            }
        });

        imageButton2.setOnClickListener((View v) -> {
            if (spinner.getSelectedItem().toString().equals("Celsius"))
            {
                float calcValue = Float.parseFloat(input.getText().toString());
                textView.setText( (String.format("%.2f", ((9*calcValue)/5 +32)))+ " Fahrenheit");
                textView2.setText( (String.format("%.2f", (calcValue + 273.151))) + " Kelvin");
                textView3.setText("");
            }
            else {
                textView.setText("");
                textView2.setText("");
                textView3.setText("");
                Toast.makeText(MainActivity.this, "Wrong Conversion Button !", Toast.LENGTH_LONG).show();
            }
        });

        imageButton3.setOnClickListener((View v) -> {
            if (spinner.getSelectedItem().toString().equals("Kilogram"))
            {
                float calcValue = Float.parseFloat(input.getText().toString());
                textView.setText( (String.format("%.2f", (1000*calcValue))) + " Grams");
                textView2.setText( (String.format("%.2f", ((35.274)*calcValue))) + " Ounces(Oz)");
                textView3.setText( (String.format("%.2f", ((2.205)*calcValue))) + " Pound(lb)");
            }
            else
            {
                textView.setText("");
                textView2.setText("");
                textView3.setText("");
                Toast.makeText( MainActivity.this ,  "Wrong Conversion Button !",Toast.LENGTH_LONG).show();
            }
        });
    }
}